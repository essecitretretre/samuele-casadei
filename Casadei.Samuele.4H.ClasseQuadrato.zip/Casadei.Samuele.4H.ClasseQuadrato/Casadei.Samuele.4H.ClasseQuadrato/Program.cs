﻿/*Realizza la classe Q (Quadrato) dotata degli attributi lato, posx e posy; questi ultimi due sono 
le coordinate cartesiane dell'angolo superiore sinistro del quadrato. 
L'oggetto di classe Q può essere istanziato solo tramite costruttore.
Prevedere i seguenti metodi: area, perimetro, diagonale.
Prevedere il sovraccarico dell'operatore logico > per confrontare due quadrati rispetto all'area di ciascuno
*/
using System;

namespace Casadei.Samuele._4H.ClasseQuadrato
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Programma Classe Quadrato di Samuele Casadei 4H\n");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("Quadrato 1: ");
            Console.ResetColor();
            Q quadrato1 = new Q(5, 6, 3);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Area: " + quadrato1.Area());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Perimetro: " + quadrato1.Perimetro());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Diagonale: {0:n2}\n" , quadrato1.Diagonale());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("Quadrato 2: ");
            Console.ResetColor();
            Q quadrato2 = new Q(3, 3, 3);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Area: " + quadrato2.Area());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Perimetro: " + quadrato2.Perimetro());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Diagonale: {0:n2}\n", quadrato2.Diagonale());
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine("Confronto Aree con operatore >:");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(quadrato1 > quadrato2);
            Console.ResetColor();

        }

    }
    class Q
    {
        //campi della classe
        public int lato;
        public int posx;
        public int posy;


        public Q() //costruttore di default
        {

        }
        public Q(int l, int x, int y)
        {
            posx = x;
            posy = y;
            lato = l;

        }
        public double Area()
        {
            return lato * lato;
           

        }
        public double Perimetro()
        {
            return lato * 4;
        }
        public double Diagonale()
        {
            return lato * Math.Sqrt(2);
        }

        //metodo pubblico statico in cui ritorna un booleano
        static public bool operator > (Q q1, Q q2)
        {
            if (q1.Area() > q2.Area())
                return true;
            else
                return false;
           

        }
        static public bool operator <(Q q1, Q q2)
        {
            if (q1.Area() > q2.Area())
                return false;
            else
                return true;


        }


    }
        

        
    
}
